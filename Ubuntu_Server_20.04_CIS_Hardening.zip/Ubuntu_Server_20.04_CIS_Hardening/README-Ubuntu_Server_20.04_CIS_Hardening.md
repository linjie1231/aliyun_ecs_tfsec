1. 增加执行权限

```
chmod +x Ubuntu_Server_20.04_CIS_Hardening.sh
```

2. 切换 root 用户

```
sudo -i
```

3. 脚本执行依赖 net-tools 库，需要提前安装

```
sudo apt-get install net-tools
```

3. 首次执行会在当前目录生成 .cisrc 文件

```
sudo ./Ubuntu_Server_20.04_CIS_Hardening.sh
```

4. 使用默认的 .cisrc 文件，或按照实际需求修改其中的配置项
5. 再次执行脚本，添加 -u 参数

```
sudo ./Ubuntu_Server_20.04_CIS_Hardening.sh -u
```