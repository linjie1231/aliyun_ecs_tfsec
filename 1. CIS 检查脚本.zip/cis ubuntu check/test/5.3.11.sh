#!/bin/sh
# ** AUTO GENERATED **

# 5.3.11 - Ensure SSH PermitEmptyPasswords is disabled (Scored)

grep "^\s*PermitEmptyPasswords" /etc/ssh/sshd_config | grep -q "PermitEmptyPasswords\s*no" || exit $?
