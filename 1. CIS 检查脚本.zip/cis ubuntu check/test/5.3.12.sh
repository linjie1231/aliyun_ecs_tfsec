#!/bin/sh
# ** AUTO GENERATED **

# 5.3.12 - Ensure SSH PermitUserEnvironment is disabled (Scored)

grep "^\s*PermitUserEnvironment" /etc/ssh/sshd_config | grep -q "PermitUserEnvironment\s*no" || exit $?
