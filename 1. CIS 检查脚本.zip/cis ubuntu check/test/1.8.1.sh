#!/bin/sh
# ** AUTO GENERATED **

# 1.8.1 - Ensure GNOME Display Manager is removed (Scored)

dpkg -s gdm3 |grep -E "not installed" || exit $?
