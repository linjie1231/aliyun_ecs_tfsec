#!/bin/sh
# ** AUTO GENERATED **

# 5.6 - Ensure root login is restricted to system console (Not Scored)

cat /etc/securetty

exit 1
