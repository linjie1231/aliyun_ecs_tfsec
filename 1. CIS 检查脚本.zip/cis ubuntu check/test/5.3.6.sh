#!/bin/sh
# ** AUTO GENERATED **

# 5.3.6 - Ensure SSH X11 forwarding is disabled (Scored)

grep "^\s*X11Forwarding" /etc/ssh/sshd_config | grep -q "X11Forwarding\s*no" || exit $?
