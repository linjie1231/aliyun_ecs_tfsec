#!/bin/sh
# ** AUTO GENERATED **

# 1.8.3 - Ensure disable-user-list is configured (Scored)

echo /etc/gdm3/greeter.dconf-defaults |grep -E "^\s*disable-user-list\s*=\s*true\b" || exit $?
