#!/bin/sh
# ** AUTO GENERATED **

# 1.2.1 - Ensure package manager repositories are configured (Not Scored)

yum repolist

exit 1
