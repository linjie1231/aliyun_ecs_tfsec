#!/bin/sh
# ** AUTO GENERATED **

# 1.1.13 - Ensure nosuid option set on /var/tmp partition (Scored)

mount | grep /var/tmp | grep nosuid || exit $?
